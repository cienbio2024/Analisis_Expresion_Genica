
# Análisis de Expresión Génica – CIENBIO

Este repositorio contiene un archivo de ejemplo en formato Excel con datos de expresión génica de genes humanos. El objetivo es servir como base para análisis en Python utilizando bibliotecas como `pandas` y `matplotlib`.

## 📄 Contenido

- `expresion_genica.xlsx`: Archivo Excel con expresión de los genes **TP53**, **BRCA1** y **EGFR**, medidos en 5 réplicas.

## 📊 Estructura de los datos

| Gen   | Muestra_1 | Muestra_2 | Muestra_3 | Muestra_4 | Muestra_5 |
|-------|-----------|-----------|-----------|-----------|-----------|
| TP53  | 120       | 115       | 130       | 125       | 110       |
| BRCA1 | 400       | 420       | 410       | 405       | 415       |
| EGFR  | 280       | 300       | 295       | 310       | 290       |
| TP53  | 140       | 135       | 150       | 145       | 138       |
| BRCA1 | 390       | 400       | 385       | 395       | 405       |

## 🔬 Aplicaciones sugeridas

- Cálculo de expresión promedio
- Visualización de perfiles génicos
- Normalización de datos
- Introducción al análisis de datos transcriptómicos

## 🧬 CIENBIO

Este material es parte del desarrollo de recursos educativos y computacionales para el análisis molecular en el contexto del laboratorio y la investigación en biotecnología, impulsado por **CIENBIO SpA**.
